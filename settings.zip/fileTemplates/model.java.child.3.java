import ru.ekd.commons.repositories.TenantCRUDRepository;
import ${PACKAGE_NAME}.business_logic.models.${Model_name};

/**
 * <p>Интерфейс репозитория для доступа к модели {@link ${Model_name}}.</p>
 */
public interface ${Model_name}Repository extends TenantCRUDRepository<${Model_name}> {
    //region Public



    //endregion
}
